package com.example.registerlogin;

public class StringRequest {
}
